

<hr>


## [v2.3.8](https://github.com/etcd-io/etcd/releases/tag/v2.3.8) (2017-02-17)

See [code changes](https://github.com/etcd-io/etcd/compare/v2.3.7...v2.3.8).

### Go

- Compile with [*Go 1.7.5*](https://golang.org/doc/devel/release.html#go1.7).


<hr>

